package countLine;
import java.io.*;

public class Count {
	public static void main(String[] args) {
		File file1 = new File("file1");
		File file2 = new File("file2");
		File file3 = new File("file3");
		
	}

}
